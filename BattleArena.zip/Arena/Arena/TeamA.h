#pragma once
#include <iostream>
#include <string>
#include <time.h>
#include <vector>
#include  "Hero.h"

using namespace std;


class TeamA : public Hero
{
public:
	TeamA();
	~TeamA();


	Hero Cj;
	Hero Ryder;
	Hero BigSmoke;




	vector<Hero> Heroesa;
	

	


	
};

