#include "pch.h"
#include "TeamB.h"


TeamB::TeamB()
{

	
}


TeamB::~TeamB()
{
}

