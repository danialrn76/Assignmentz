#include "pch.h"
#include "TeamA.h"


TeamA::TeamA()
{
	Cj.SetHeroName("Cj");
	BigSmoke.SetHeroName("Big Smoke");
	BigSmoke.SetHeroName("Ryder");
}


TeamA::~TeamA()
{
}






