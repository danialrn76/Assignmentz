#include "HashFunction.h"
#include "pch.h"
#include <iostream>
using namespace std;

namespace HashFunction {


	// implementation of a basic addition hash
	unsigned int badHash(const char* data, unsigned int length) {

		unsigned int hash = 0;

		for (unsigned int i = 0; i < length; ++i)

			hash += data[i] * (i + 1);

		

		cout << hash;
		return hash;
	}


}